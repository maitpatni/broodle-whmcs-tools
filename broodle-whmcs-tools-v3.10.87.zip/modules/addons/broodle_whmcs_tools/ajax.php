<?php
/**
 * Broodle WHMCS Tools — AJAX Handler for Email & Domain Actions
 *
 * @package    BroodleWHMCSTools
 * @author     Broodle
 * @link       https://broodle.host
 */

define('CLIENTAREA', true);

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/clientfunctions.php';

use WHMCS\Database\Capsule;

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

// Verify logged-in client
$ca = new WHMCS\ClientArea();
$ca->initPage();
if (!$ca->isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}
$clientId = (int) $ca->getUserID();

$action    = isset($_POST['action']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['action']) : '';
$serviceId = isset($_POST['service_id']) ? (int) $_POST['service_id'] : 0;

if (!$serviceId || !$action) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

// Verify the service belongs to this client
$service = Capsule::table('tblhosting')->where('id', $serviceId)->first();
if (!$service || (int) $service->userid !== $clientId) {
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit;
}

// Check feature toggle based on action
$domainActions = ['get_parent_domains', 'add_addon_domain', 'add_subdomain', 'delete_domain'];
$dbActions = ['list_databases', 'create_database', 'create_db_user', 'delete_database', 'delete_db_user', 'assign_db_user', 'get_phpmyadmin_url'];
$sslActions = ['ssl_status', 'start_autossl', 'autossl_progress', 'autossl_problems'];
$dnsActions = ['dns_list_domains', 'dns_fetch_records', 'dns_add_record', 'dns_edit_record', 'dns_delete_record', 'dns_bulk_delete'];
$cronActions = ['cron_list', 'cron_add', 'cron_edit', 'cron_delete'];
$phpActions = ['php_get_versions', 'php_set_version'];
$logActions = ['error_log_read', 'error_log_clear'];
$analyticsActions = ['analytics_bandwidth', 'analytics_visitors', 'analytics_log_archives', 'analytics_bandwidth_detailed'];
$fileActions = ['fm_list', 'fm_read', 'fm_save', 'fm_create_file', 'fm_create_folder', 'fm_delete', 'fm_rename', 'fm_copy', 'fm_move', 'fm_upload', 'fm_permissions', 'fm_compress', 'fm_extract', 'fm_search', 'fm_download_url'];

// Handle addon description lookup (no cPanel needed)
if ($action === 'get_addon_description') {
    $addonId = isset($_POST['addon_id']) ? (int) $_POST['addon_id'] : 0;
    if (!$addonId) {
        echo json_encode(['success' => false, 'message' => 'Missing addon ID']);
        exit;
    }
    $addon = Capsule::table('tbladdons')->where('id', $addonId)->first();
    if (!$addon) {
        echo json_encode(['success' => false, 'message' => 'Addon not found']);
        exit;
    }
    $desc = strip_tags($addon->description ?? '');
    // Get pricing — use client's currency, fallback to currency 1
    $clientCurrency = Capsule::table('tblclients')->where('id', $clientId)->value('currency') ?: 1;
    $pricing = Capsule::table('tblpricing')
        ->where('type', 'addon')
        ->where('relid', $addonId)
        ->where('currency', $clientCurrency)
        ->first();
    $currency = Capsule::table('tblcurrencies')->where('id', $clientCurrency)->first();
    $prefix = $currency->prefix ?? '';
    $suffix = $currency->suffix ?? '';
    $price = '';
    $cycle = $addon->billingcycle ?? '';
    if ($pricing) {
        if ($pricing->monthly > 0) $price = $prefix . number_format($pricing->monthly, 2) . $suffix . '/mo';
        elseif ($pricing->quarterly > 0) $price = $prefix . number_format($pricing->quarterly, 2) . $suffix . '/qtr';
        elseif ($pricing->semiannually > 0) $price = $prefix . number_format($pricing->semiannually, 2) . $suffix . '/6mo';
        elseif ($pricing->annually > 0) $price = $prefix . number_format($pricing->annually, 2) . $suffix . '/yr';
        elseif ($pricing->biennially > 0) $price = $prefix . number_format($pricing->biennially, 2) . $suffix . '/2yr';
        elseif ($pricing->triennially > 0) $price = $prefix . number_format($pricing->triennially, 2) . $suffix . '/3yr';
        if (strtolower($cycle) === 'onetime' && $pricing->monthly > 0) $price = $prefix . number_format($pricing->monthly, 2) . $suffix . ' one-time';
    }
    echo json_encode(['success' => true, 'description' => $desc, 'price' => trim($price)]);
    exit;
}

// Handle addons list for service (no cPanel needed)
if ($action === 'get_addons') {
    $clientCurrency = Capsule::table('tblclients')->where('id', $clientId)->value('currency') ?: 1;
    $currency = Capsule::table('tblcurrencies')->where('id', $clientCurrency)->first();
    $prefix = $currency->prefix ?? '';
    $suffix = $currency->suffix ?? '';

    // Active addons on this service
    $activeAddons = Capsule::table('tblhostingaddons')
        ->where('hostingid', $serviceId)
        ->get()
        ->map(function ($ha) use ($prefix, $suffix, $clientCurrency) {
            $addon = Capsule::table('tbladdons')->where('id', $ha->addonid)->first();
            $name = $ha->name ?: ($addon ? $addon->name : 'Addon #' . $ha->addonid);
            $status = ucfirst($ha->status ?? 'active');
            $nextDue = $ha->nextduedate ?? '';
            $cycle = $ha->billingcycle ?? '';
            $amount = $ha->recurring ?? '0.00';
            $priceStr = '';
            if ((float)$amount > 0) {
                $cycleLabel = '';
                $cl = strtolower($cycle);
                if ($cl === 'monthly') $cycleLabel = '/mo';
                elseif ($cl === 'quarterly') $cycleLabel = '/qtr';
                elseif ($cl === 'semi-annually' || $cl === 'semiannually') $cycleLabel = '/6mo';
                elseif ($cl === 'annually') $cycleLabel = '/yr';
                elseif ($cl === 'biennially') $cycleLabel = '/2yr';
                elseif ($cl === 'triennially') $cycleLabel = '/3yr';
                elseif ($cl === 'one time' || $cl === 'onetime') $cycleLabel = ' one-time';
                $priceStr = $prefix . number_format((float)$amount, 2) . $suffix . $cycleLabel;
            }
            return [
                'id' => $ha->id,
                'addonId' => $ha->addonid,
                'name' => $name,
                'description' => $addon ? strip_tags($addon->description ?? '', '<p><br><ul><ol><li><strong><b><em><i><a><span><div><h1><h2><h3><h4><h5><h6>') : '',
                'status' => $status,
                'nextDue' => $nextDue,
                'price' => $priceStr,
                'billingCycle' => $cycle,
            ];
        })->toArray();

    // Available addons for this product (not yet purchased or can be purchased again)
    $productId = $service->packageid;
    $availableAddons = [];
    $allAddons = Capsule::table('tbladdons')
        ->where(function ($q) use ($productId) {
            $q->where('packages', '')
              ->orWhereNull('packages')
              ->orWhere('packages', 'like', '%,' . $productId . ',%')
              ->orWhere('packages', 'like', $productId . ',%')
              ->orWhere('packages', 'like', '%,' . $productId)
              ->orWhere('packages', $productId);
        })
        ->where('showorder', 1)
        ->where(function ($q) {
            $q->where('retired', 0)->orWhereNull('retired');
        })
        ->get();

    foreach ($allAddons as $addon) {
        // Check if already active on this service
        $alreadyActive = Capsule::table('tblhostingaddons')
            ->where('hostingid', $serviceId)
            ->where('addonid', $addon->id)
            ->whereIn('status', ['Active', 'Pending', 'Suspended'])
            ->exists();

        // Get pricing
        $pricing = Capsule::table('tblpricing')
            ->where('type', 'addon')
            ->where('relid', $addon->id)
            ->where('currency', $clientCurrency)
            ->first();
        $priceStr = '';
        if ($pricing) {
            if ($pricing->monthly > 0) $priceStr = $prefix . number_format($pricing->monthly, 2) . $suffix . '/mo';
            elseif ($pricing->quarterly > 0) $priceStr = $prefix . number_format($pricing->quarterly, 2) . $suffix . '/qtr';
            elseif ($pricing->semiannually > 0) $priceStr = $prefix . number_format($pricing->semiannually, 2) . $suffix . '/6mo';
            elseif ($pricing->annually > 0) $priceStr = $prefix . number_format($pricing->annually, 2) . $suffix . '/yr';
            elseif ($pricing->biennially > 0) $priceStr = $prefix . number_format($pricing->biennially, 2) . $suffix . '/2yr';
            elseif ($pricing->triennially > 0) $priceStr = $prefix . number_format($pricing->triennially, 2) . $suffix . '/3yr';
            $cl = strtolower($addon->billingcycle ?? '');
            if ($cl === 'onetime' && $pricing->monthly > 0) $priceStr = $prefix . number_format($pricing->monthly, 2) . $suffix . ' one-time';
        }

        $availableAddons[] = [
            'id' => $addon->id,
            'name' => $addon->name,
            'description' => strip_tags($addon->description ?? '', '<p><br><ul><ol><li><strong><b><em><i><a><span><div><h1><h2><h3><h4><h5><h6>'),
            'price' => $priceStr,
            'billingCycle' => $addon->billingcycle ?? '',
            'alreadyActive' => $alreadyActive,
        ];
    }

    // Configurable options for this product
    $configOptions = [];
    $configGroup = Capsule::table('tblproductconfiglinks')
        ->where('pid', $productId)
        ->pluck('gid');
    if ($configGroup && count($configGroup) > 0) {
        $options = Capsule::table('tblproductconfigoptions')
            ->whereIn('gid', $configGroup)
            ->where('hidden', 0)
            ->orderBy('order')
            ->get();
        foreach ($options as $opt) {
            $subs = Capsule::table('tblproductconfigoptionssub')
                ->where('configid', $opt->id)
                ->where('hidden', 0)
                ->orderBy('sortorder')
                ->get();
            $choices = [];
            foreach ($subs as $sub) {
                $subPricing = Capsule::table('tblpricing')
                    ->where('type', 'configoptions')
                    ->where('relid', $sub->id)
                    ->where('currency', $clientCurrency)
                    ->first();
                $subPrice = '';
                if ($subPricing && $subPricing->monthly > 0) {
                    $subPrice = $prefix . number_format($subPricing->monthly, 2) . $suffix . '/mo';
                }
                $choices[] = [
                    'id' => $sub->id,
                    'name' => $sub->optionname,
                    'price' => $subPrice,
                ];
            }
            // Get current selection for this service
            $currentVal = Capsule::table('tblhostingconfigoptions')
                ->where('relid', $serviceId)
                ->where('configid', $opt->id)
                ->value('optionid');
            $configOptions[] = [
                'id' => $opt->id,
                'name' => $opt->optionname,
                'type' => $opt->optiontype, // 1=dropdown, 2=radio, 3=yesno, 4=quantity
                'choices' => $choices,
                'currentValue' => $currentVal ? (int)$currentVal : null,
            ];
        }
    }

    echo json_encode([
        'success' => true,
        'activeAddons' => $activeAddons,
        'availableAddons' => $availableAddons,
        'configOptions' => $configOptions,
    ]);
    exit;
}

// Handle cPanel resource stats (CPU, Memory, I/O, Processes) — per-user only
if ($action === 'cpanel_resource_stats') {
    $server = Capsule::table('tblservers')->where('id', $service->server)->first();
    if (!$server) { echo json_encode(['success' => false, 'message' => 'Server not found']); exit; }
    $hostname = $server->hostname;
    $port = !empty($server->port) ? (int) $server->port : 2087;
    $serverUser = $server->username;
    $secure = !empty($server->secure) && ($server->secure === 'on' || $server->secure === '1' || $server->secure === 1);
    $protocol = $secure ? 'https' : 'http';
    $cpUsername = $service->username;
    $accessHash = ''; $password = '';
    if (!empty($server->accesshash)) {
        $raw = trim($server->accesshash);
        if (preg_match('/^[A-Za-z0-9]{10,64}$/', $raw)) $accessHash = $raw;
        else { $accessHash = trim(decrypt($raw)); if (empty($accessHash) || !preg_match('/^[A-Za-z0-9]{10,64}$/', $accessHash)) $accessHash = ''; }
    }
    if (empty($accessHash) && !empty($server->password)) $password = trim(decrypt($server->password));
    if (empty($accessHash) && empty($password)) { echo json_encode(['success' => false, 'message' => 'Server credentials unavailable']); exit; }
    $headers = [];
    if (!empty($accessHash)) $headers[] = "Authorization: whm {$serverUser}:{$accessHash}";

    $stats = ['cpu' => null, 'mem' => null, 'io' => null, 'nproc' => null, 'ep' => null, 'iops' => null];

    // Helper: make a cPanel UAPI call via WHM proxy for this specific user
    $uapiCall = function ($module, $func, $params = '') use ($protocol, $hostname, $port, $cpUsername, $headers, $serverUser, $password) {
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=" . urlencode($module)
             . "&cpanel_jsonapi_func=" . urlencode($func)
             . ($params ? "&{$params}" : '');
        $ch = curl_init();
        curl_setopt_array($ch, [CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false]);
        if (!empty($headers)) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        elseif (!empty($password)) curl_setopt($ch, CURLOPT_USERPWD, "{$serverUser}:{$password}");
        $resp = curl_exec($ch); curl_close($ch);
        return json_decode($resp, true);
    };

    // Strategy 1: UAPI StatsBar::get_stats — returns per-user account stats
    // Fields: _count (current), _max (limit), id, name, units, percent
    $json1 = $uapiCall('StatsBar', 'get_stats', 'display=' . urlencode('diskusage|bandwidthusage|emailaccounts|ftpaccounts|sqldatabases|addondomains|subdomains|parkeddomains'));
    $sbData = $json1['result']['data'] ?? [];
    $accountStats = [];
    if (is_array($sbData)) {
        foreach ($sbData as $sb) {
            if (!is_array($sb)) continue;
            $id = $sb['id'] ?? ($sb['name'] ?? '');
            $accountStats[$id] = [
                'count' => $sb['_count'] ?? ($sb['count'] ?? null),
                'max' => $sb['_max'] ?? ($sb['max'] ?? null),
                'percent' => $sb['percent'] ?? 0,
                'item' => $sb['item'] ?? $id,
                'units' => $sb['units'] ?? '',
            ];
        }
    }

    // Strategy 2: UAPI ResourceUsage::get_usages — per-user CloudLinux/LVE resource limits
    // Response items have: id, description, usage, maximum, formatter (format_bytes|format_bytes_per_second|null)
    $json2 = $uapiCall('ResourceUsage', 'get_usages');
    $usages = $json2['result']['data'] ?? [];
    if (is_array($usages) && !empty($usages)) {
        foreach ($usages as $u) {
            if (!is_array($u)) continue;
            $id = strtolower($u['id'] ?? '');
            $desc = strtolower($u['description'] ?? '');
            $used = $u['usage'] ?? ($u['used'] ?? ($u['value'] ?? null));
            $max = $u['maximum'] ?? ($u['limit'] ?? ($u['max'] ?? null));
            $formatter = $u['formatter'] ?? null;
            if ($max === 'unlimited' || $max === null || $max === 0 || $max === '0' || $max === '-1') $max = 0;
            if ($used !== null) $used = floatval($used);
            if ($max !== null && $max !== 0) $max = floatval($max);
            $item = ['used' => $used, 'max' => $max, 'formatter' => $formatter, 'desc' => $u['description'] ?? ''];

            if (strpos($id, 'cpu') !== false || strpos($desc, 'cpu') !== false) $stats['cpu'] = $item;
            elseif ($id === 'physicalmemoryusage' || $id === 'disk_usage' && false || strpos($id, 'pmem') !== false || strpos($desc, 'physical memory') !== false || (strpos($desc, 'memory') !== false && strpos($desc, 'virtual') === false)) $stats['mem'] = $item;
            elseif (strpos($id, 'iops') !== false || strpos($desc, 'iops') !== false) $stats['iops'] = $item;
            elseif (strpos($id, 'io') !== false || strpos($desc, 'i/o') !== false) $stats['io'] = $item;
            elseif ($id === 'entryprocesses' || strpos($id, 'ep') !== false || strpos($desc, 'entry process') !== false) $stats['ep'] = $item;
            elseif (strpos($id, 'nproc') !== false || strpos($id, 'process') !== false || strpos($desc, 'process') !== false) $stats['nproc'] = $item;
        }
    }

    // Strategy 3: CloudLinux LVEInfo::getUsage fallback for CPU/mem
    if ($stats['cpu'] === null || $stats['mem'] === null) {
        $json3 = $uapiCall('LVEInfo', 'getUsage');
        $lveData = $json3['result']['data'] ?? ($json3['cpanelresult']['data'] ?? []);
        if (is_array($lveData) && !empty($lveData)) {
            $lve = isset($lveData[0]) ? $lveData[0] : $lveData;
            if (isset($lve['cpu']) && $stats['cpu'] === null) {
                $stats['cpu'] = ['used' => $lve['cpu']['used'] ?? $lve['cpu'], 'max' => $lve['cpu']['limit'] ?? ($lve['lcpu'] ?? 100), 'formatter' => null];
            }
            if (isset($lve['pmem']) && $stats['mem'] === null) {
                $stats['mem'] = ['used' => $lve['pmem']['used'] ?? $lve['pmem'], 'max' => $lve['pmem']['limit'] ?? ($lve['lpmem'] ?? 0), 'formatter' => 'format_bytes'];
            }
            if (isset($lve['io']) && $stats['io'] === null) {
                $stats['io'] = ['used' => $lve['io']['used'] ?? $lve['io'], 'max' => $lve['io']['limit'] ?? ($lve['lio'] ?? 0), 'formatter' => 'format_bytes_per_second'];
            }
            if (isset($lve['nproc']) && $stats['nproc'] === null) {
                $stats['nproc'] = ['used' => $lve['nproc']['used'] ?? $lve['nproc'], 'max' => $lve['nproc']['limit'] ?? ($lve['lnproc'] ?? 0), 'formatter' => null];
            }
            if (isset($lve['ep']) && $stats['ep'] === null) {
                $stats['ep'] = ['used' => $lve['ep']['used'] ?? $lve['ep'], 'max' => $lve['ep']['limit'] ?? ($lve['lep'] ?? 0), 'formatter' => null];
            }
            if (isset($lve['iops']) && $stats['iops'] === null) {
                $stats['iops'] = ['used' => $lve['iops']['used'] ?? $lve['iops'], 'max' => $lve['iops']['limit'] ?? ($lve['liops'] ?? 0), 'formatter' => null];
            }
        }
    }

    echo json_encode(['success' => true, 'stats' => $stats, 'account' => $accountStats]);
    exit;
}

// Handle cPanel SSO URL generation for shortcuts
if ($action === 'get_cpanel_sso_url') {
    $gotoPage = isset($_POST['page']) ? trim($_POST['page']) : '';
    $ssoService = isset($_POST['sso_service']) ? trim($_POST['sso_service']) : 'cpaneld';
    // Only allow known services
    if (!in_array($ssoService, ['cpaneld', 'webmaild'])) $ssoService = 'cpaneld';
    $server = Capsule::table('tblservers')->where('id', $service->server)->first();
    if (!$server) { echo json_encode(['success' => false, 'message' => 'Server not found']); exit; }
    $hostname = $server->hostname;
    $port = !empty($server->port) ? (int) $server->port : 2087;
    $serverUser = $server->username;
    $secure = !empty($server->secure) && ($server->secure === 'on' || $server->secure === '1' || $server->secure === 1);
    $protocol = $secure ? 'https' : 'http';
    $cpUsername = $service->username;
    $accessHash = ''; $password = '';
    if (!empty($server->accesshash)) {
        $raw = trim($server->accesshash);
        if (preg_match('/^[A-Za-z0-9]{10,64}$/', $raw)) $accessHash = $raw;
        else { $accessHash = trim(decrypt($raw)); if (empty($accessHash) || !preg_match('/^[A-Za-z0-9]{10,64}$/', $accessHash)) $accessHash = ''; }
    }
    if (empty($accessHash) && !empty($server->password)) $password = trim(decrypt($server->password));
    if (empty($accessHash) && empty($password)) { echo json_encode(['success' => false, 'message' => 'Server credentials unavailable']); exit; }
    $headers = [];
    if (!empty($accessHash)) $headers[] = "Authorization: whm {$serverUser}:{$accessHash}";
    // Create user session via WHM API
    $ssoUrl = "{$protocol}://{$hostname}:{$port}/json-api/create_user_session?api.version=1&user=" . urlencode($cpUsername) . "&service=" . urlencode($ssoService);
    $ch = curl_init();
    curl_setopt_array($ch, [CURLOPT_URL => $ssoUrl, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => false]);
    if (!empty($headers)) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    elseif (!empty($password)) curl_setopt($ch, CURLOPT_USERPWD, "{$serverUser}:{$password}");
    $resp = curl_exec($ch); curl_close($ch);
    $json = json_decode($resp, true);
    $sessionUrl = $json['data']['url'] ?? '';
    $cpSecurityToken = $json['data']['cp_security_token'] ?? '';
    if (empty($sessionUrl)) { echo json_encode(['success' => false, 'message' => 'Could not create cPanel session']); exit; }
    // Build the final URL with goto_uri for page redirect
    // cPanel SSO flow: create_user_session returns a login URL like:
    //   https://server:2083/cpsessXXXX/login/?session=TOKEN
    // To redirect after login, append goto_uri parameter.
    // The goto_uri must be a URL-encoded path WITHOUT the cpsess prefix.
    // cPanel automatically prepends the session prefix to the goto_uri.
    if ($gotoPage && $ssoService === 'cpaneld') {
        if (preg_match('#(https?://[^/]+)(/cpsess[^/]+)#', $sessionUrl, $m)) {
            $baseUrl = $m[1];
            $cpsess = $cpSecurityToken ?: $m[2];
            $parts = parse_url($sessionUrl);
            parse_str($parts['query'] ?? '', $qs);
            $sessionToken = $qs['session'] ?? '';
            if ($sessionToken) {
                $gotoPage = ltrim($gotoPage, '/');
                // Map common shortcut names to actual cPanel paths
                $pageMap = [
                    'filemanager' => 'frontend/jupiter/filemanager/index.html',
                    'email' => 'frontend/jupiter/email_accounts/index.html',
                    'databases' => 'frontend/jupiter/sql/index.html',
                    'phpmyadmin' => '3rdparty/phpMyAdmin/index.php',
                    'domains' => 'frontend/jupiter/domains/index.html',
                    'subdomains' => 'frontend/jupiter/domains/index.html',
                    'ssl' => 'frontend/jupiter/ssl/index.html',
                    'cron' => 'frontend/jupiter/cron/index.html',
                    'dns' => 'frontend/jupiter/zone_editor/index.html',
                    'php' => 'frontend/jupiter/multiphp_manager/index.html',
                    'backup' => 'frontend/jupiter/backup/index.html',
                    'rawlogs' => 'frontend/jupiter/raw/index.html',
                    'terminal' => 'frontend/jupiter/terminal/index.html',
                ];
                $mappedPage = $pageMap[strtolower($gotoPage)] ?? null;
                if (!$mappedPage) {
                    if (strpos($gotoPage, 'frontend/') === 0 || strpos($gotoPage, '3rdparty/') === 0) {
                        $mappedPage = $gotoPage;
                    } else {
                        $mappedPage = 'frontend/jupiter/' . $gotoPage;
                    }
                }
                // goto_uri should be the path relative to the cpsess prefix
                // cPanel expects: /cpsessXXXX/login/?session=TOKEN&goto_uri=/cpsessXXXX/PAGE
                $gotoUri = $cpsess . '/' . $mappedPage;
                $sessionUrl = $baseUrl . $cpsess . '/login/?session=' . urlencode($sessionToken) . '&goto_uri=' . urlencode($gotoUri);
            }
        }
    }
    echo json_encode(['success' => true, 'url' => $sessionUrl, 'cp_security_token' => $cpSecurityToken]);
    exit;
}

if (in_array($action, $domainActions)) {
    $featureKey = 'tweak_domain_management';
} elseif (in_array($action, $dbActions)) {
    $featureKey = 'tweak_database_management';
} elseif (in_array($action, $sslActions)) {
    $featureKey = 'tweak_ssl_management';
} elseif (in_array($action, $dnsActions)) {
    $featureKey = 'tweak_dns_management';
} elseif (in_array($action, $cronActions)) {
    $featureKey = 'tweak_cron_management';
} elseif (in_array($action, $phpActions)) {
    $featureKey = 'tweak_php_version';
} elseif (in_array($action, $logActions)) {
    $featureKey = 'tweak_error_logs';
} elseif (in_array($action, $analyticsActions)) {
    $featureKey = 'tweak_analytics';
} elseif (in_array($action, $fileActions)) {
    $featureKey = 'tweak_file_manager';
} else {
    $featureKey = 'tweak_email_list';
}

$enabled = Capsule::table('mod_broodle_tools_settings')
    ->where('setting_key', $featureKey)
    ->value('setting_value');
if ($enabled !== '1') {
    echo json_encode(['success' => false, 'message' => 'Feature disabled']);
    exit;
}

// Get server info
$server = Capsule::table('tblservers')->where('id', $service->server)->first();
if (!$server) {
    echo json_encode(['success' => false, 'message' => 'Server not found']);
    exit;
}

$hostname   = $server->hostname;
$port       = !empty($server->port) ? (int) $server->port : 2087;
$serverUser = $server->username;
$secure     = !empty($server->secure) && ($server->secure === 'on' || $server->secure === '1' || $server->secure === 1);
$protocol   = $secure ? 'https' : 'http';
$cpUsername  = $service->username;

// Resolve auth
$accessHash = '';
$password   = '';
if (!empty($server->accesshash)) {
    $raw = trim($server->accesshash);
    if (preg_match('/^[A-Za-z0-9]{10,64}$/', $raw)) {
        $accessHash = $raw;
    } else {
        $accessHash = trim(decrypt($raw));
        if (empty($accessHash) || !preg_match('/^[A-Za-z0-9]{10,64}$/', $accessHash)) {
            $accessHash = '';
        }
    }
}
if (empty($accessHash) && !empty($server->password)) {
    $password = trim(decrypt($server->password));
}
if (empty($accessHash) && empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Server credentials unavailable']);
    exit;
}

/** Make a WHM API call. */
function broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url, $timeout = 20)
{
    $headers = [];
    if (!empty($accessHash)) {
        $headers[] = "Authorization: whm {$serverUser}:{$accessHash}";
    }
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    } elseif (!empty($password)) {
        curl_setopt($ch, CURLOPT_USERPWD, "{$serverUser}:{$password}");
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $httpCode, 'body' => $response];
}

/** Helper to parse UAPI result status. */
function broodle_ajax_parse_result($r)
{
    if ($r['code'] !== 200 || !$r['body']) return ['ok' => false, 'error' => 'Failed to connect to server'];
    $json = json_decode($r['body'], true);
    $status = $json['result']['status'] ?? ($json['cpanelresult']['data'][0]['result'] ?? null);
    if ($status == 1 || $status === true) return ['ok' => true];
    $err = $json['result']['errors'][0] ?? ($json['cpanelresult']['data'][0]['reason'] ?? 'Unknown error');
    return ['ok' => false, 'error' => $err];
}

// ── Route actions ──

switch ($action) {

    case 'create_email':
        $emailUser = isset($_POST['email_user']) ? trim($_POST['email_user']) : '';
        $emailPass = isset($_POST['email_pass']) ? $_POST['email_pass'] : '';
        $domain    = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $quota     = isset($_POST['quota']) ? (int) $_POST['quota'] : 250;

        if (empty($emailUser) || empty($emailPass) || empty($domain)) {
            echo json_encode(['success' => false, 'message' => 'Please fill in all fields']);
            exit;
        }
        if (!preg_match('/^[a-zA-Z0-9._-]+$/', $emailUser)) {
            echo json_encode(['success' => false, 'message' => 'Invalid email username']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Email"
             . "&cpanel_jsonapi_func=add_pop"
             . "&email=" . urlencode($emailUser)
             . "&password=" . urlencode($emailPass)
             . "&domain=" . urlencode($domain)
             . "&quota=" . $quota;

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Email account created' : $p['error'], 'email' => $emailUser . '@' . $domain]);
        break;

    case 'change_password':
        $emailFull = isset($_POST['email']) ? trim($_POST['email']) : '';
        $newPass   = isset($_POST['new_pass']) ? $_POST['new_pass'] : '';

        if (empty($emailFull) || empty($newPass)) {
            echo json_encode(['success' => false, 'message' => 'Please fill in all fields']);
            exit;
        }
        $parts = explode('@', $emailFull, 2);
        if (count($parts) !== 2) {
            echo json_encode(['success' => false, 'message' => 'Invalid email address']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Email"
             . "&cpanel_jsonapi_func=passwd_pop"
             . "&email=" . urlencode($parts[0])
             . "&password=" . urlencode($newPass)
             . "&domain=" . urlencode($parts[1]);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Password changed successfully' : $p['error']]);
        break;

    case 'delete_email':
        $emailFull = isset($_POST['email']) ? trim($_POST['email']) : '';
        if (empty($emailFull)) { echo json_encode(['success' => false, 'message' => 'Missing email']); exit; }
        $parts = explode('@', $emailFull, 2);
        if (count($parts) !== 2) { echo json_encode(['success' => false, 'message' => 'Invalid email']); exit; }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Email"
             . "&cpanel_jsonapi_func=delete_pop"
             . "&email=" . urlencode($parts[0])
             . "&domain=" . urlencode($parts[1]);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Email account deleted' : $p['error']]);
        break;

    case 'webmail_login':
        $emailFull = isset($_POST['email']) ? trim($_POST['email']) : '';
        if (empty($emailFull)) { echo json_encode(['success' => false, 'message' => 'Missing email']); exit; }

        // Create a webmail session via WHM API
        $url = "{$protocol}://{$hostname}:{$port}/json-api/create_user_session"
             . "?api.version=1"
             . "&user=" . urlencode($cpUsername)
             . "&service=webmaild";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);

        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $sessionUrl = $json['data']['url'] ?? '';
            if (!empty($sessionUrl)) {
                // Webmail SSO URL goes directly to webmail login — append Roundcube path
                if (preg_match('#(https?://[^/]+)(/cpsess[^/]+)#', $sessionUrl, $m)) {
                    $baseUrl = $m[1];
                    $cpsess = $json['data']['cp_security_token'] ?? $m[2];
                    $parts = parse_url($sessionUrl);
                    parse_str($parts['query'] ?? '', $qs);
                    $sessionToken = $qs['session'] ?? '';
                    if ($sessionToken) {
                        $gotoUri = $cpsess . '/3rdparty/roundcube/?_task=mail&_mbox=INBOX';
                        $roundcubeUrl = $baseUrl . $cpsess . '/login/?session=' . urlencode($sessionToken) . '&goto_uri=' . urlencode($gotoUri);
                        echo json_encode(['success' => true, 'url' => $roundcubeUrl]);
                        break;
                    }
                }
                echo json_encode(['success' => true, 'url' => $sessionUrl]);
                break;
            }
        }

        // Fallback: direct webmail URL
        $webmailPort = $secure ? 2096 : 2095;
        echo json_encode(['success' => true, 'url' => "{$protocol}://{$hostname}:{$webmailPort}/"]);
        break;

    case 'get_domains':
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=DomainInfo"
             . "&cpanel_jsonapi_func=list_domains";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        $domains = [];
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $data = $json['result']['data'] ?? ($json['cpanelresult']['data'] ?? []);
            if (!empty($data)) {
                if (isset($data['main_domain'])) $domains[] = $data['main_domain'];
                if (!empty($data['addon_domains'])) $domains = array_merge($domains, $data['addon_domains']);
                if (!empty($data['parked_domains'])) $domains = array_merge($domains, $data['parked_domains']);
                if (!empty($data['sub_domains'])) {
                    foreach ($data['sub_domains'] as $sd) {
                        if (!in_array($sd, $domains)) $domains[] = $sd;
                    }
                }
            }
        }
        if (empty($domains) && !empty($service->domain)) $domains[] = $service->domain;
        $domains = array_unique($domains);
        sort($domains);
        echo json_encode(['success' => true, 'domains' => $domains]);
        break;

    case 'get_parent_domains':
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=DomainInfo"
             . "&cpanel_jsonapi_func=list_domains";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        $domains = [];
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $data = $json['result']['data'] ?? ($json['cpanelresult']['data'] ?? []);
            if (!empty($data)) {
                if (isset($data['main_domain'])) $domains[] = $data['main_domain'];
                if (!empty($data['addon_domains'])) $domains = array_merge($domains, $data['addon_domains']);
            }
        }
        if (empty($domains) && !empty($service->domain)) $domains[] = $service->domain;
        $domains = array_unique($domains);
        sort($domains);
        echo json_encode(['success' => true, 'domains' => $domains]);
        break;

    case 'add_addon_domain':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $docroot = isset($_POST['docroot']) ? trim($_POST['docroot']) : '';

        if (empty($domain)) { echo json_encode(['success' => false, 'message' => 'Please enter a domain name']); exit; }
        if (!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $domain)) {
            echo json_encode(['success' => false, 'message' => 'Invalid domain name']); exit;
        }
        if (empty($docroot)) $docroot = $domain;

        // Use AddonDomain::addaddondomain (cPanel API 2)
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=AddonDomain"
             . "&cpanel_jsonapi_func=addaddondomain"
             . "&newdomain=" . urlencode($domain)
             . "&subdomain=" . urlencode(str_replace('.', '', $domain))
             . "&dir=" . urlencode($docroot);

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        $p = broodle_ajax_parse_result($r);

        // If legacy module fails, try SubDomain::addsubdomain as fallback (some cPanel versions treat addons as subdomains)
        if (!$p['ok'] && strpos($p['error'], 'module') !== false) {
            $url2 = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                  . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                  . "&cpanel_jsonapi_apiversion=2"
                  . "&cpanel_jsonapi_module=SubDomain"
                  . "&cpanel_jsonapi_func=addsubdomain"
                  . "&domain=" . urlencode($domain)
                  . "&rootdomain=" . urlencode($service->domain)
                  . "&dir=" . urlencode($docroot);
            $r2 = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url2);
            $p = broodle_ajax_parse_result($r2);
        }

        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Domain added successfully' : $p['error'], 'domain' => $domain, 'type' => 'addon']);
        break;

    case 'add_subdomain':
        $subdomain = isset($_POST['subdomain']) ? trim($_POST['subdomain']) : '';
        $domain    = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $docroot   = isset($_POST['docroot']) ? trim($_POST['docroot']) : '';

        if (empty($subdomain) || empty($domain)) { echo json_encode(['success' => false, 'message' => 'Please fill in all fields']); exit; }
        if (!preg_match('/^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$/', $subdomain)) {
            echo json_encode(['success' => false, 'message' => 'Invalid subdomain name']); exit;
        }
        if (empty($docroot)) $docroot = $subdomain . '.' . $domain;

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=SubDomain"
             . "&cpanel_jsonapi_func=addsubdomain"
             . "&domain=" . urlencode($subdomain)
             . "&rootdomain=" . urlencode($domain)
             . "&dir=" . urlencode($docroot);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        $fullSub = $subdomain . '.' . $domain;
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Subdomain created successfully' : $p['error'], 'domain' => $fullSub, 'type' => 'sub']);
        break;

    case 'delete_domain':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $type   = isset($_POST['type']) ? trim($_POST['type']) : '';

        if (empty($domain) || empty($type)) { echo json_encode(['success' => false, 'message' => 'Missing parameters']); exit; }
        if ($type === 'main') { echo json_encode(['success' => false, 'message' => 'Cannot delete the primary domain']); exit; }

        $url = '';
        if ($type === 'addon') {
            // AddonDomain::deladdondomain (cPanel API 2)
            $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=AddonDomain"
                 . "&cpanel_jsonapi_func=deladdondomain"
                 . "&domain=" . urlencode($domain)
                 . "&subdomain=" . urlencode(str_replace('.', '', $domain) . '.' . ($service->domain ?? ''));
        } elseif ($type === 'sub') {
            // SubDomain::delsubdomain (cPanel API 2)
            $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=SubDomain"
                 . "&cpanel_jsonapi_func=delsubdomain"
                 . "&domain=" . urlencode($domain);
        } elseif ($type === 'parked') {
            // Park::unpark (cPanel API 2)
            $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=Park"
                 . "&cpanel_jsonapi_func=unpark"
                 . "&domain=" . urlencode($domain);
        } else {
            echo json_encode(['success' => false, 'message' => 'Unknown domain type']); exit;
        }

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Domain deleted successfully' : $p['error']]);
        break;

    // ── Database Management Actions ──

    case 'list_databases':
        $databases = [];
        $users = [];
        $mappings = [];
        $prefix = $cpUsername . '_';

        // Primary: UAPI Mysql::list_databases — returns {database, users[], disk_usage} per entry
        $urlDbs = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=list_databases";
        $rDbs = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlDbs);

        $gotMappings = false;
        if ($rDbs['code'] === 200 && $rDbs['body']) {
            $json = json_decode($rDbs['body'], true);
            $dbList = $json['result']['data'] ?? [];
            if (is_array($dbList)) {
                foreach ($dbList as $db) {
                    if (!is_array($db)) continue;
                    $dbName = $db['database'] ?? ($db['db'] ?? '');
                    if (!$dbName) continue;
                    $databases[] = $dbName;
                    // UAPI returns users as a plain string array: ["user1", "user2"]
                    if (!empty($db['users']) && is_array($db['users'])) {
                        $gotMappings = true;
                        foreach ($db['users'] as $u) {
                            $uName = is_string($u) ? $u : ($u['user'] ?? '');
                            if ($uName) $mappings[] = ['db' => $dbName, 'user' => $uName];
                        }
                    }
                }
            }
        }

        // Fallback: cPanel API 2 MysqlFE::listdbs — returns {db, userlist: [{db,user}], usercount}
        if (empty($databases)) {
            $urlListDbs = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=MysqlFE"
                 . "&cpanel_jsonapi_func=listdbs";
            $rListDbs = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlListDbs);
            if ($rListDbs['code'] === 200 && $rListDbs['body']) {
                $json = json_decode($rListDbs['body'], true);
                $dbList = $json['cpanelresult']['data'] ?? [];
                if (is_array($dbList) && !empty($dbList)) {
                    foreach ($dbList as $db) {
                        $dbName = $db['db'] ?? '';
                        if (!$dbName) continue;
                        $databases[] = $dbName;
                        // userlist is an array of {db, user} objects
                        $userList = $db['userlist'] ?? [];
                        if (is_array($userList)) {
                            $gotMappings = true;
                            foreach ($userList as $entry) {
                                $uName = is_array($entry) ? ($entry['user'] ?? '') : '';
                                if ($uName) $mappings[] = ['db' => $dbName, 'user' => $uName];
                            }
                        }
                    }
                }
            }
        }

        // UAPI Mysql::list_users — returns {user, shortuser, databases[]}
        $urlUsers = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=list_users";
        $rUsers = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlUsers);
        if ($rUsers['code'] === 200 && $rUsers['body']) {
            $json = json_decode($rUsers['body'], true);
            $uList = $json['result']['data'] ?? [];
            if (is_array($uList)) {
                foreach ($uList as $u) {
                    if (!is_array($u)) continue;
                    $uName = $u['user'] ?? '';
                    if ($uName) {
                        $users[] = $uName;
                        // list_users also returns databases per user — use as fallback mappings
                        if (!$gotMappings && !empty($u['databases']) && is_array($u['databases'])) {
                            foreach ($u['databases'] as $dbName) {
                                if (is_string($dbName) && $dbName) {
                                    $mappings[] = ['db' => $dbName, 'user' => $uName];
                                }
                            }
                        }
                    }
                }
            }
        }

        echo json_encode([
            'success' => true,
            'databases' => array_values(array_unique($databases)),
            'users' => array_values(array_unique($users)),
            'mappings' => $mappings,
            'prefix' => $prefix,
        ]);
        break;

    case 'create_database':
        $dbname = isset($_POST['dbname']) ? trim($_POST['dbname']) : '';
        if (empty($dbname)) {
            echo json_encode(['success' => false, 'message' => 'Please enter a database name']);
            exit;
        }
        // Prepend prefix if not already present
        $prefix = $cpUsername . '_';
        $fullName = (strpos($dbname, $prefix) === 0) ? $dbname : $prefix . $dbname;

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=create_database"
             . "&name=" . urlencode($fullName);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Database created: ' . $fullName : $p['error']]);
        break;

    case 'create_db_user':
        $dbuser = isset($_POST['dbuser']) ? trim($_POST['dbuser']) : '';
        $dbpass = isset($_POST['dbpass']) ? $_POST['dbpass'] : '';
        if (empty($dbuser) || empty($dbpass)) {
            echo json_encode(['success' => false, 'message' => 'Please fill in all fields']);
            exit;
        }
        $prefix = $cpUsername . '_';
        $fullUser = (strpos($dbuser, $prefix) === 0) ? $dbuser : $prefix . $dbuser;

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=create_user"
             . "&name=" . urlencode($fullUser)
             . "&password=" . urlencode($dbpass);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'User created: ' . $fullUser : $p['error']]);
        break;

    case 'delete_database':
        $database = isset($_POST['database']) ? trim($_POST['database']) : '';
        if (empty($database)) {
            echo json_encode(['success' => false, 'message' => 'Missing database name']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=delete_database"
             . "&name=" . urlencode($database);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Database deleted' : $p['error']]);
        break;

    case 'delete_db_user':
        $dbuser = isset($_POST['dbuser']) ? trim($_POST['dbuser']) : '';
        if (empty($dbuser)) {
            echo json_encode(['success' => false, 'message' => 'Missing username']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=delete_user"
             . "&name=" . urlencode($dbuser);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'User deleted' : $p['error']]);
        break;

    case 'assign_db_user':
        $database = isset($_POST['database']) ? trim($_POST['database']) : '';
        $dbuser   = isset($_POST['dbuser']) ? trim($_POST['dbuser']) : '';
        $privileges = isset($_POST['privileges']) ? trim($_POST['privileges']) : 'ALL PRIVILEGES';

        if (empty($database) || empty($dbuser)) {
            echo json_encode(['success' => false, 'message' => 'Select a database and user']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Mysql"
             . "&cpanel_jsonapi_func=set_privileges_on_database"
             . "&user=" . urlencode($dbuser)
             . "&database=" . urlencode($database)
             . "&privileges=" . urlencode($privileges);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Privileges assigned successfully' : $p['error']]);
        break;

    case 'get_phpmyadmin_url':
        // Create a cPanel session and return phpMyAdmin URL with proper SSO login
        $url = "{$protocol}://{$hostname}:{$port}/json-api/create_user_session"
             . "?api.version=1"
             . "&user=" . urlencode($cpUsername)
             . "&service=cpaneld";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);

        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $sessionUrl = $json['data']['url'] ?? '';
            $cpSecurityToken = $json['data']['cp_security_token'] ?? '';
            if (!empty($sessionUrl)) {
                if (preg_match('#(https?://[^/]+)(/cpsess[^/]+)#', $sessionUrl, $m)) {
                    $baseUrl = $m[1];
                    $cpsess = $cpSecurityToken ?: $m[2];
                    $parts = parse_url($sessionUrl);
                    parse_str($parts['query'] ?? '', $qs);
                    $sessionToken = $qs['session'] ?? '';
                    if ($sessionToken) {
                        $gotoUri = $cpsess . '/3rdparty/phpMyAdmin/index.php';
                        $pmaUrl = $baseUrl . $cpsess . '/login/?session=' . urlencode($sessionToken) . '&goto_uri=' . urlencode($gotoUri);
                        echo json_encode(['success' => true, 'url' => $pmaUrl]);
                        break;
                    }
                }
                echo json_encode(['success' => true, 'url' => $sessionUrl]);
                break;
            }
        }

        // Fallback: direct cPanel URL
        $cpPort = $secure ? 2083 : 2082;
        echo json_encode(['success' => true, 'url' => "{$protocol}://{$hostname}:{$cpPort}/3rdparty/phpMyAdmin/index.php"]);
        break;

    // ── SSL Management Actions ──

    case 'ssl_status':
        // Step 1: Get all domains for this account
        $urlDomains = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=DomainInfo"
             . "&cpanel_jsonapi_func=list_domains";
        $rDom = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlDomains);
        $allDomains = [];
        if ($rDom['code'] === 200 && $rDom['body']) {
            $jsonDom = json_decode($rDom['body'], true);
            $domData = $jsonDom['result']['data'] ?? [];
            if (!empty($domData['main_domain'])) $allDomains[] = $domData['main_domain'];
            if (!empty($domData['addon_domains'])) $allDomains = array_merge($allDomains, $domData['addon_domains']);
            if (!empty($domData['parked_domains'])) $allDomains = array_merge($allDomains, $domData['parked_domains']);
        }
        if (empty($allDomains) && !empty($service->domain)) $allDomains[] = $service->domain;
        $allDomains = array_unique($allDomains);

        // Step 2: Get SSL info via installed_hosts
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=SSL"
             . "&cpanel_jsonapi_func=installed_hosts";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url, 30);

        // Build a map of domain => cert info from installed_hosts
        $sslMap = [];
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $hosts = $json['result']['data'] ?? [];

            if (is_array($hosts)) {
                foreach ($hosts as $host) {
                    if (!is_array($host)) continue;
                    $domain = $host['servername'] ?? '';
                    if (!$domain) continue;

                    $cert = [];
                    $cert['domain'] = $domain;
                    $cert['has_cert'] = true;

                    // Certificate details are nested under 'certificate' object
                    $certObj = $host['certificate'] ?? [];
                    if (!is_array($certObj)) $certObj = [];

                    // Issuer is a nested object: certificate.issuer.organizationName / certificate.issuer.commonName
                    $issuerObj = $certObj['issuer'] ?? [];
                    if (is_array($issuerObj)) {
                        $issuerOrg = $issuerObj['organizationName'] ?? '';
                        $issuerCN = $issuerObj['commonName'] ?? '';
                    } else {
                        // Fallback if issuer is a string
                        $issuerOrg = '';
                        $issuerCN = is_string($issuerObj) ? $issuerObj : '';
                    }
                    $cert['issuer'] = $issuerOrg ?: $issuerCN ?: 'Unknown';

                    // Self-signed: certificate.is_self_signed (integer 0/1)
                    $isSelfSigned = !empty($certObj['is_self_signed']);

                    $cert['is_self_signed'] = $isSelfSigned;
                    $cert['self_signed'] = $isSelfSigned;

                    // Expiry: certificate.not_after (epoch)
                    $expiryEpoch = $certObj['not_after'] ?? null;
                    if ($expiryEpoch) {
                        $cert['expiry_epoch'] = (int) $expiryEpoch;
                        $cert['expiry_date'] = date('Y-m-d', (int) $expiryEpoch);
                    }

                    // AutoSSL flag: certificate.is_autossl (integer 0/1)
                    $isAutoSSL = !empty($certObj['is_autossl']);

                    // Type detection
                    $issuerLower = strtolower($cert['issuer']);
                    if ($isSelfSigned) {
                        $cert['type'] = 'self-signed';
                    } elseif ($isAutoSSL) {
                        // Use the autossl provider display name if available
                        $providerName = $certObj['auto_ssl_provider_display_name'] ?? ($certObj['auto_ssl_provider'] ?? '');
                        if ($providerName) {
                            $cert['issuer'] = $providerName . ' (AutoSSL)';
                        } elseif (strpos($issuerLower, 'let\'s encrypt') !== false || strpos($issuerLower, 'letsencrypt') !== false) {
                            $cert['issuer'] = "Let's Encrypt";
                        } elseif (strpos($issuerLower, 'comodo') !== false || strpos($issuerLower, 'sectigo') !== false) {
                            $cert['issuer'] = 'Sectigo (AutoSSL)';
                        } else {
                            $cert['issuer'] = $cert['issuer'] ?: 'AutoSSL';
                        }
                        $cert['type'] = 'autossl';
                    } elseif (strpos($issuerLower, 'let\'s encrypt') !== false || strpos($issuerLower, 'letsencrypt') !== false) {
                        $cert['type'] = 'autossl';
                        $cert['issuer'] = "Let's Encrypt";
                    } elseif (strpos($issuerLower, 'comodo') !== false || strpos($issuerLower, 'sectigo') !== false) {
                        $cert['type'] = 'autossl';
                        $cert['issuer'] = 'Sectigo (AutoSSL)';
                    } elseif (strpos($issuerLower, 'cpanel') !== false) {
                        $cert['type'] = 'autossl';
                        $cert['issuer'] = 'cPanel AutoSSL';
                    } else {
                        $cert['type'] = 'commercial';
                    }

                    $sslMap[strtolower($domain)] = $cert;

                    // Also map all covered domains from certificate.domains array
                    $coveredDomains = $certObj['domains'] ?? [];
                    if (is_array($coveredDomains)) {
                        foreach ($coveredDomains as $covDom) {
                            if (is_string($covDom) && !isset($sslMap[strtolower($covDom)])) {
                                $covCert = $cert;
                                $covCert['domain'] = $covDom;
                                $sslMap[strtolower($covDom)] = $covCert;
                            }
                        }
                    }
                }
            }
        }

        // Step 3: Merge — every domain gets an entry, with SSL info if available
        $certificates = [];
        foreach ($allDomains as $dom) {
            $key = strtolower($dom);
            if (isset($sslMap[$key])) {
                $certificates[] = $sslMap[$key];
                unset($sslMap[$key]);
            } else {
                $certificates[] = [
                    'domain' => $dom,
                    'has_cert' => false,
                    'issuer' => '',
                    'is_self_signed' => false,
                    'self_signed' => false,
                    'type' => 'none',
                ];
            }
        }
        // Add any remaining SSL hosts not in the domain list (e.g. mail/cpanel subdomains)
        foreach ($sslMap as $extra) {
            $certificates[] = $extra;
        }

        echo json_encode(['success' => true, 'certificates' => $certificates]);
        break;

    case 'start_autossl':
        // Use WHM API start_autossl_check_for_one_user (more reliable than UAPI when called via WHM)
        $url = "{$protocol}://{$hostname}:{$port}/json-api/start_autossl_check_for_one_user"
             . "?api.version=1"
             . "&username=" . urlencode($cpUsername);

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url, 30);

        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $meta = $json['metadata'] ?? [];
            $status = $meta['result'] ?? ($json['result']['status'] ?? 0);
            if ($status == 1) {
                echo json_encode(['success' => true, 'message' => 'AutoSSL check started']);
            } else {
                $err = $meta['reason'] ?? ($json['result']['errors'][0] ?? 'Failed to start AutoSSL');
                // Fallback: try UAPI method
                $urlUapi = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                     . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                     . "&cpanel_jsonapi_apiversion=3"
                     . "&cpanel_jsonapi_module=SSL"
                     . "&cpanel_jsonapi_func=start_autossl_check";
                $r2 = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlUapi, 30);
                if ($r2['code'] === 200 && $r2['body']) {
                    $json2 = json_decode($r2['body'], true);
                    if (($json2['result']['status'] ?? 0) == 1) {
                        echo json_encode(['success' => true, 'message' => 'AutoSSL check started']);
                        break;
                    }
                }
                echo json_encode(['success' => false, 'message' => $err]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    case 'autossl_progress':
        // Use UAPI SSL::is_autossl_check_in_progress
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=SSL"
             . "&cpanel_jsonapi_func=is_autossl_check_in_progress";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);

        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $inProgress = $json['result']['data'] ?? false;
            // The API returns 1 or true if in progress
            echo json_encode(['success' => true, 'in_progress' => (bool) $inProgress]);
        } else {
            echo json_encode(['success' => true, 'in_progress' => false]);
        }
        break;

    case 'autossl_problems':
        // Use UAPI SSL::get_autossl_problems
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=SSL"
             . "&cpanel_jsonapi_func=get_autossl_problems";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        $problems = [];

        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $data = $json['result']['data'] ?? [];
            if (is_array($data)) {
                foreach ($data as $item) {
                    if (!is_array($item)) continue;
                    $problems[] = [
                        'domain' => $item['domain'] ?? ($item['vhost_name'] ?? 'Unknown'),
                        'problem' => $item['problem'] ?? ($item['message'] ?? 'Unknown issue'),
                    ];
                }
            }
        }

        echo json_encode(['success' => true, 'problems' => $problems]);
        break;

    // ── DNS Management Actions ──

    case 'dns_list_domains':
        // Get all domains for this cPanel account
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=DomainInfo"
             . "&cpanel_jsonapi_func=list_domains";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        $domains = [];
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $data = $json['result']['data'] ?? [];
            if (!empty($data['main_domain'])) $domains[] = ['domain' => $data['main_domain'], 'type' => 'main'];
            if (!empty($data['addon_domains'])) {
                foreach ($data['addon_domains'] as $d) $domains[] = ['domain' => $d, 'type' => 'addon'];
            }
            if (!empty($data['parked_domains'])) {
                foreach ($data['parked_domains'] as $d) $domains[] = ['domain' => $d, 'type' => 'parked'];
            }
            if (!empty($data['sub_domains'])) {
                $addonSet = array_map('strtolower', $data['addon_domains'] ?? []);
                $mainDomain = strtolower($data['main_domain'] ?? '');
                foreach ($data['sub_domains'] as $sd) {
                    $sdLower = strtolower($sd);
                    $isAddonSub = false;
                    foreach ($addonSet as $ad) {
                        if ($sdLower === strtolower($ad) . '.' . $mainDomain) { $isAddonSub = true; break; }
                    }
                    if (!$isAddonSub) $domains[] = ['domain' => $sd, 'type' => 'sub'];
                }
            }
        }
        if (empty($domains) && !empty($service->domain)) {
            $domains[] = ['domain' => $service->domain, 'type' => 'main'];
        }
        echo json_encode(['success' => true, 'domains' => $domains]);
        break;

    case 'dns_fetch_records':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        if (empty($domain)) {
            echo json_encode(['success' => false, 'message' => 'Missing domain']);
            exit;
        }

        // Use cPanel API 2 ZoneEdit::fetchzone_records (no UAPI equivalent exists)
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=ZoneEdit"
             . "&cpanel_jsonapi_func=fetchzone_records"
             . "&domain=" . urlencode($domain)
             . "&customonly=0";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url, 30);
        $records = [];
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $data = $json['cpanelresult']['data'] ?? [];
            foreach ($data as $rec) {
                if (!is_array($rec)) continue;
                $type = $rec['type'] ?? '';
                // Skip raw/comment lines and $TTL directives
                if ($type === ':RAW' || $type === '$TTL' || $type === '') continue;
                $record = [
                    'line'    => $rec['Line'] ?? ($rec['line'] ?? 0),
                    'type'    => $type,
                    'name'    => $rec['name'] ?? '',
                    'ttl'     => (int)($rec['ttl'] ?? 14400),
                    'class'   => $rec['class'] ?? 'IN',
                ];
                switch ($type) {
                    case 'A':
                    case 'AAAA':
                        $record['address'] = $rec['address'] ?? '';
                        break;
                    case 'CNAME':
                        $record['cname'] = $rec['cname'] ?? '';
                        break;
                    case 'MX':
                        $record['exchange'] = $rec['exchange'] ?? '';
                        $record['preference'] = (int)($rec['preference'] ?? 0);
                        break;
                    case 'TXT':
                        $record['txtdata'] = $rec['txtdata'] ?? '';
                        break;
                    case 'SRV':
                        $record['priority'] = (int)($rec['priority'] ?? 0);
                        $record['weight'] = (int)($rec['weight'] ?? 0);
                        $record['port'] = (int)($rec['port'] ?? 0);
                        $record['target'] = $rec['target'] ?? '';
                        break;
                    case 'CAA':
                        $record['flag'] = (int)($rec['flag'] ?? 0);
                        $record['tag'] = $rec['tag'] ?? '';
                        $record['value'] = $rec['value'] ?? '';
                        break;
                    case 'NS':
                        $record['nsdname'] = $rec['nsdname'] ?? '';
                        break;
                    case 'SOA':
                        $record['mname'] = $rec['mname'] ?? '';
                        $record['rname'] = $rec['rname'] ?? '';
                        $record['serial'] = $rec['serial'] ?? '';
                        $record['refresh'] = (int)($rec['refresh'] ?? 0);
                        $record['retry'] = (int)($rec['retry'] ?? 0);
                        $record['expire'] = (int)($rec['expire'] ?? 0);
                        $record['minimum'] = (int)($rec['minimum'] ?? 0);
                        break;
                }
                $records[] = $record;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch DNS records']);
            exit;
        }
        echo json_encode(['success' => true, 'records' => $records, 'domain' => $domain]);
        break;

    case 'dns_add_record':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $type   = isset($_POST['type']) ? strtoupper(trim($_POST['type'])) : '';
        $name   = isset($_POST['name']) ? trim($_POST['name']) : '';
        $ttl    = isset($_POST['ttl']) ? (int) $_POST['ttl'] : 14400;

        if (empty($domain) || empty($type)) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }

        // Build the API URL based on record type
        $params = "&domain=" . urlencode($domain)
                . "&name=" . urlencode($name)
                . "&type=" . urlencode($type)
                . "&ttl=" . $ttl
                . "&class=IN";

        switch ($type) {
            case 'A':
            case 'AAAA':
                $address = isset($_POST['address']) ? trim($_POST['address']) : '';
                if (empty($address)) { echo json_encode(['success' => false, 'message' => 'IP address is required']); exit; }
                $params .= "&address=" . urlencode($address);
                break;
            case 'CNAME':
                $cname = isset($_POST['cname']) ? trim($_POST['cname']) : '';
                if (empty($cname)) { echo json_encode(['success' => false, 'message' => 'CNAME target is required']); exit; }
                $params .= "&cname=" . urlencode($cname);
                break;
            case 'MX':
                $exchange = isset($_POST['exchange']) ? trim($_POST['exchange']) : '';
                $preference = isset($_POST['preference']) ? (int) $_POST['preference'] : 10;
                if (empty($exchange)) { echo json_encode(['success' => false, 'message' => 'Mail server is required']); exit; }
                $params .= "&exchange=" . urlencode($exchange) . "&preference=" . $preference;
                break;
            case 'TXT':
                $txtdata = isset($_POST['txtdata']) ? trim($_POST['txtdata']) : '';
                if (empty($txtdata)) { echo json_encode(['success' => false, 'message' => 'TXT data is required']); exit; }
                $params .= "&txtdata=" . urlencode($txtdata);
                break;
            case 'SRV':
                $priority = isset($_POST['priority']) ? (int) $_POST['priority'] : 0;
                $weight = isset($_POST['weight']) ? (int) $_POST['weight'] : 0;
                $srvPort = isset($_POST['port']) ? (int) $_POST['port'] : 0;
                $target = isset($_POST['target']) ? trim($_POST['target']) : '';
                if (empty($target)) { echo json_encode(['success' => false, 'message' => 'Target is required']); exit; }
                $params .= "&priority=" . $priority . "&weight=" . $weight . "&port=" . $srvPort . "&target=" . urlencode($target);
                break;
            case 'CAA':
                $flag = isset($_POST['flag']) ? (int) $_POST['flag'] : 0;
                $tag = isset($_POST['tag']) ? trim($_POST['tag']) : 'issue';
                $value = isset($_POST['value']) ? trim($_POST['value']) : '';
                if (empty($value)) { echo json_encode(['success' => false, 'message' => 'CAA value is required']); exit; }
                $params .= "&flag=" . $flag . "&tag=" . urlencode($tag) . "&value=" . urlencode($value);
                break;
            default:
                echo json_encode(['success' => false, 'message' => 'Unsupported record type: ' . $type]);
                exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=ZoneEdit"
             . "&cpanel_jsonapi_func=add_zone_record"
             . $params;

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $cpResult = $json['cpanelresult']['data'][0] ?? [];
            $status = $cpResult['result']['status'] ?? ($cpResult['status'] ?? ($cpResult['result'] ?? 0));
            if ($status == 1 || $status === true) {
                $newLine = $cpResult['result']['newserial'] ?? ($cpResult['newserial'] ?? '');
                echo json_encode(['success' => true, 'message' => 'DNS record added successfully', 'newserial' => $newLine]);
            } else {
                $err = $cpResult['result']['statusmsg'] ?? ($cpResult['statusmsg'] ?? ($cpResult['result']['message'] ?? 'Failed to add record'));
                echo json_encode(['success' => false, 'message' => $err]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    case 'dns_edit_record':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $line   = isset($_POST['line']) ? (int) $_POST['line'] : 0;
        $type   = isset($_POST['type']) ? strtoupper(trim($_POST['type'])) : '';
        $name   = isset($_POST['name']) ? trim($_POST['name']) : '';
        $ttl    = isset($_POST['ttl']) ? (int) $_POST['ttl'] : 14400;

        if (empty($domain) || !$line || empty($type)) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }

        $params = "&domain=" . urlencode($domain)
                . "&Line=" . $line
                . "&name=" . urlencode($name)
                . "&type=" . urlencode($type)
                . "&ttl=" . $ttl
                . "&class=IN";

        switch ($type) {
            case 'A':
            case 'AAAA':
                $address = isset($_POST['address']) ? trim($_POST['address']) : '';
                $params .= "&address=" . urlencode($address);
                break;
            case 'CNAME':
                $cname = isset($_POST['cname']) ? trim($_POST['cname']) : '';
                $params .= "&cname=" . urlencode($cname);
                break;
            case 'MX':
                $exchange = isset($_POST['exchange']) ? trim($_POST['exchange']) : '';
                $preference = isset($_POST['preference']) ? (int) $_POST['preference'] : 10;
                $params .= "&exchange=" . urlencode($exchange) . "&preference=" . $preference;
                break;
            case 'TXT':
                $txtdata = isset($_POST['txtdata']) ? trim($_POST['txtdata']) : '';
                $params .= "&txtdata=" . urlencode($txtdata);
                break;
            case 'SRV':
                $priority = isset($_POST['priority']) ? (int) $_POST['priority'] : 0;
                $weight = isset($_POST['weight']) ? (int) $_POST['weight'] : 0;
                $srvPort = isset($_POST['port']) ? (int) $_POST['port'] : 0;
                $target = isset($_POST['target']) ? trim($_POST['target']) : '';
                $params .= "&priority=" . $priority . "&weight=" . $weight . "&port=" . $srvPort . "&target=" . urlencode($target);
                break;
            case 'CAA':
                $flag = isset($_POST['flag']) ? (int) $_POST['flag'] : 0;
                $tag = isset($_POST['tag']) ? trim($_POST['tag']) : 'issue';
                $value = isset($_POST['value']) ? trim($_POST['value']) : '';
                $params .= "&flag=" . $flag . "&tag=" . urlencode($tag) . "&value=" . urlencode($value);
                break;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=ZoneEdit"
             . "&cpanel_jsonapi_func=edit_zone_record"
             . $params;

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $cpResult = $json['cpanelresult']['data'][0] ?? [];
            $status = $cpResult['result']['status'] ?? ($cpResult['status'] ?? ($cpResult['result'] ?? 0));
            if ($status == 1 || $status === true) {
                echo json_encode(['success' => true, 'message' => 'DNS record updated successfully']);
            } else {
                $err = $cpResult['result']['statusmsg'] ?? ($cpResult['statusmsg'] ?? 'Failed to update record');
                echo json_encode(['success' => false, 'message' => $err]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    case 'dns_delete_record':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $line   = isset($_POST['line']) ? (int) $_POST['line'] : 0;

        if (empty($domain) || !$line) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=ZoneEdit"
             . "&cpanel_jsonapi_func=remove_zone_record"
             . "&domain=" . urlencode($domain)
             . "&line=" . $line;

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $cpResult = $json['cpanelresult']['data'][0] ?? [];
            $status = $cpResult['result']['status'] ?? ($cpResult['status'] ?? ($cpResult['result'] ?? 0));
            if ($status == 1 || $status === true) {
                echo json_encode(['success' => true, 'message' => 'DNS record deleted']);
            } else {
                $err = $cpResult['result']['statusmsg'] ?? ($cpResult['statusmsg'] ?? 'Failed to delete record');
                echo json_encode(['success' => false, 'message' => $err]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    case 'dns_bulk_delete':
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $lines  = isset($_POST['lines']) ? trim($_POST['lines']) : '';

        if (empty($domain) || empty($lines)) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }

        $lineArr = array_filter(array_map('intval', explode(',', $lines)));
        if (empty($lineArr)) {
            echo json_encode(['success' => false, 'message' => 'No valid line numbers']);
            exit;
        }

        // Delete in reverse order to avoid line number shifts
        rsort($lineArr);
        $deleted = 0;
        $errors = [];
        foreach ($lineArr as $line) {
            $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=ZoneEdit"
                 . "&cpanel_jsonapi_func=remove_zone_record"
                 . "&domain=" . urlencode($domain)
                 . "&line=" . $line;

            $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
            if ($r['code'] === 200 && $r['body']) {
                $json = json_decode($r['body'], true);
                $cpResult = $json['cpanelresult']['data'][0] ?? [];
                $status = $cpResult['result']['status'] ?? ($cpResult['status'] ?? ($cpResult['result'] ?? 0));
                if ($status == 1 || $status === true) {
                    $deleted++;
                } else {
                    $errors[] = "Line {$line}: " . ($cpResult['result']['statusmsg'] ?? 'Failed');
                }
            } else {
                $errors[] = "Line {$line}: Connection failed";
            }
        }

        $msg = "Deleted {$deleted} of " . count($lineArr) . " records";
        if (!empty($errors)) $msg .= '. Errors: ' . implode('; ', array_slice($errors, 0, 3));
        echo json_encode(['success' => $deleted > 0, 'message' => $msg, 'deleted' => $deleted, 'total' => count($lineArr)]);
        break;

    // ── Cron Jobs Management Actions ──

    case 'cron_list':
        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Cron"
             . "&cpanel_jsonapi_func=list_cron";

        $r = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url);
        $jobs = [];
        if ($r['code'] === 200 && $r['body']) {
            $json = json_decode($r['body'], true);
            $data = $json['result']['data'] ?? [];
            if (is_array($data)) {
                foreach ($data as $job) {
                    if (!is_array($job)) continue;
                    $jobs[] = [
                        'linekey'  => $job['linekey'] ?? '',
                        'minute'   => $job['minute'] ?? '*',
                        'hour'     => $job['hour'] ?? '*',
                        'day'      => $job['day'] ?? '*',
                        'month'    => $job['month'] ?? '*',
                        'weekday'  => $job['weekday'] ?? '*',
                        'command'  => $job['command'] ?? '',
                    ];
                }
            }
        }
        $emailUrl = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Cron"
             . "&cpanel_jsonapi_func=get_email";
        $rEmail = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $emailUrl);
        $cronEmail = '';
        if ($rEmail['code'] === 200 && $rEmail['body']) {
            $ej = json_decode($rEmail['body'], true);
            $cronEmail = $ej['result']['data']['email'] ?? '';
        }
        echo json_encode(['success' => true, 'jobs' => $jobs, 'cron_email' => $cronEmail]);
        break;

    case 'cron_add':
        $minute  = isset($_POST['minute']) ? trim($_POST['minute']) : '*';
        $hour    = isset($_POST['hour']) ? trim($_POST['hour']) : '*';
        $day     = isset($_POST['day']) ? trim($_POST['day']) : '*';
        $month   = isset($_POST['month']) ? trim($_POST['month']) : '*';
        $weekday = isset($_POST['weekday']) ? trim($_POST['weekday']) : '*';
        $command = isset($_POST['command']) ? trim($_POST['command']) : '';

        if (empty($command)) {
            echo json_encode(['success' => false, 'message' => 'Command is required']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Cron"
             . "&cpanel_jsonapi_func=add_line"
             . "&minute=" . urlencode($minute)
             . "&hour=" . urlencode($hour)
             . "&day=" . urlencode($day)
             . "&month=" . urlencode($month)
             . "&weekday=" . urlencode($weekday)
             . "&command=" . urlencode($command);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Cron job added successfully' : $p['error']]);
        break;

    case 'cron_edit':
        $linekey = isset($_POST['linekey']) ? trim($_POST['linekey']) : '';
        $minute  = isset($_POST['minute']) ? trim($_POST['minute']) : '*';
        $hour    = isset($_POST['hour']) ? trim($_POST['hour']) : '*';
        $day     = isset($_POST['day']) ? trim($_POST['day']) : '*';
        $month   = isset($_POST['month']) ? trim($_POST['month']) : '*';
        $weekday = isset($_POST['weekday']) ? trim($_POST['weekday']) : '*';
        $command = isset($_POST['command']) ? trim($_POST['command']) : '';

        if (empty($linekey) || empty($command)) {
            echo json_encode(['success' => false, 'message' => 'Missing parameters']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Cron"
             . "&cpanel_jsonapi_func=edit_line"
             . "&linekey=" . urlencode($linekey)
             . "&minute=" . urlencode($minute)
             . "&hour=" . urlencode($hour)
             . "&day=" . urlencode($day)
             . "&month=" . urlencode($month)
             . "&weekday=" . urlencode($weekday)
             . "&command=" . urlencode($command);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Cron job updated successfully' : $p['error']]);
        break;

    case 'cron_delete':
        $linekey = isset($_POST['linekey']) ? trim($_POST['linekey']) : '';
        if (empty($linekey)) {
            echo json_encode(['success' => false, 'message' => 'Missing line key']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Cron"
             . "&cpanel_jsonapi_func=remove_line"
             . "&linekey=" . urlencode($linekey);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'Cron job deleted' : $p['error']]);
        break;

    // ── PHP Version Management Actions ──

    case 'php_get_versions':
        // Strategy 1: Try UAPI LangPHP::php_get_installed_versions
        $urlInstalled = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=LangPHP"
             . "&cpanel_jsonapi_func=php_get_installed_versions";

        $rInstalled = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlInstalled);
        $installed = [];
        $debugInfo = '';
        if ($rInstalled['code'] === 200 && $rInstalled['body']) {
            $json = json_decode($rInstalled['body'], true);
            $status = $json['result']['status'] ?? 0;
            if ($status == 1) {
                $rawData = $json['result']['data'] ?? [];
                // Handle both formats: {versions: [...]} and direct array [...]
                if (is_array($rawData) && isset($rawData['versions']) && is_array($rawData['versions'])) {
                    $installed = $rawData['versions'];
                } elseif (is_array($rawData)) {
                    $installed = $rawData;
                }
                // Clean: extract version strings from mixed formats
                $cleanInstalled = [];
                foreach ($installed as $v) {
                    if (is_string($v)) $cleanInstalled[] = $v;
                    elseif (is_array($v) && isset($v['version'])) $cleanInstalled[] = $v['version'];
                }
                $installed = !empty($cleanInstalled) ? $cleanInstalled : [];
            }
            if (empty($installed)) {
                $debugInfo = 'LangPHP::installed_versions status=' . ($status ?? 'null');
                if (!empty($json['result']['errors'])) $debugInfo .= ': ' . ($json['result']['errors'][0] ?? '');
            }
        } else {
            $debugInfo = 'LangPHP HTTP ' . $rInstalled['code'];
        }

        // Strategy 2: If LangPHP failed, try cPanel API 2 LangPHP::fetchLangPHP
        if (empty($installed)) {
            $urlApi2 = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=LangPHP"
                 . "&cpanel_jsonapi_func=fetchLangPHP";

            $rApi2 = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlApi2);
            if ($rApi2['code'] === 200 && $rApi2['body']) {
                $json2 = json_decode($rApi2['body'], true);
                $data2 = $json2['cpanelresult']['data'] ?? [];
                if (is_array($data2)) {
                    foreach ($data2 as $item) {
                        if (is_array($item) && isset($item['version'])) {
                            $installed[] = $item['version'];
                        }
                    }
                }
                if (empty($installed)) {
                    $debugInfo .= '. API2 LangPHP::fetchLangPHP also empty';
                }
            }
        }

        // Strategy 3: Try WHM API php_get_installed_versions directly
        if (empty($installed)) {
            $urlWhm = "{$protocol}://{$hostname}:{$port}/json-api/php_get_installed_versions?api.version=1";
            $rWhm = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlWhm);
            if ($rWhm['code'] === 200 && $rWhm['body']) {
                $jsonWhm = json_decode($rWhm['body'], true);
                $whmVersions = $jsonWhm['data']['versions'] ?? ($jsonWhm['versions'] ?? []);
                if (is_array($whmVersions)) {
                    foreach ($whmVersions as $v) {
                        if (is_string($v)) $installed[] = $v;
                        elseif (is_array($v) && isset($v['version'])) $installed[] = $v['version'];
                    }
                }
            }
        }

        // Strategy 4: Try WHM API php_get_handlers to extract available PHP versions
        if (empty($installed)) {
            $urlHandlers = "{$protocol}://{$hostname}:{$port}/json-api/php_get_handlers?api.version=1";
            $rHandlers = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlHandlers);
            if ($rHandlers['code'] === 200 && $rHandlers['body']) {
                $jsonH = json_decode($rHandlers['body'], true);
                $handlers = $jsonH['data']['php'] ?? ($jsonH['data'] ?? []);
                if (is_array($handlers)) {
                    foreach ($handlers as $h) {
                        if (is_array($h) && isset($h['version'])) {
                            $ver = $h['version'];
                            if (!in_array($ver, $installed)) $installed[] = $ver;
                        }
                    }
                }
            }
        }

        // Get vhost versions
        $urlVhosts = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=LangPHP"
             . "&cpanel_jsonapi_func=php_get_vhost_versions";

        $rVhosts = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlVhosts);
        $vhosts = [];
        if ($rVhosts['code'] === 200 && $rVhosts['body']) {
            $json = json_decode($rVhosts['body'], true);
            $status = $json['result']['status'] ?? 0;
            if ($status == 1) {
                $data = $json['result']['data'] ?? [];
                if (is_array($data)) {
                    foreach ($data as $vh) {
                        if (!is_array($vh)) continue;
                        $vhosts[] = [
                            'vhost'       => $vh['vhost'] ?? '',
                            'version'     => $vh['version'] ?? '',
                            'php_admin'   => $vh['php_admin'] ?? false,
                            'documentroot'=> $vh['documentroot'] ?? '',
                        ];
                    }
                }
            }
        }

        // Fallback: if no vhosts from UAPI, try cPanel API 2
        if (empty($vhosts)) {
            $urlVhApi2 = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=2"
                 . "&cpanel_jsonapi_module=LangPHP"
                 . "&cpanel_jsonapi_func=fetchLangPHP";

            $rVhApi2 = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlVhApi2);
            if ($rVhApi2['code'] === 200 && $rVhApi2['body']) {
                $json2 = json_decode($rVhApi2['body'], true);
                $data2 = $json2['cpanelresult']['data'] ?? [];
                if (is_array($data2)) {
                    foreach ($data2 as $item) {
                        if (is_array($item) && isset($item['vhost'])) {
                            $vhosts[] = [
                                'vhost'       => $item['vhost'] ?? '',
                                'version'     => $item['version'] ?? '',
                                'php_admin'   => $item['php_admin'] ?? false,
                                'documentroot'=> $item['documentroot'] ?? '',
                            ];
                        }
                    }
                }
            }
        }

        // If still no vhosts, create a synthetic entry for the main domain
        if (empty($vhosts) && !empty($cpUsername)) {
            // Get the main domain from the account
            $urlDomain = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3"
                 . "&cpanel_jsonapi_module=DomainInfo"
                 . "&cpanel_jsonapi_func=list_domains";

            $rDomain = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlDomain);
            if ($rDomain['code'] === 200 && $rDomain['body']) {
                $jsonD = json_decode($rDomain['body'], true);
                $mainDomain = $jsonD['result']['data']['main_domain'] ?? '';
                if (!empty($mainDomain)) {
                    $vhosts[] = [
                        'vhost'       => $mainDomain,
                        'version'     => '',
                        'php_admin'   => false,
                        'documentroot'=> '',
                    ];
                }
                // Also add addon domains
                $addonDomains = $jsonD['result']['data']['addon_domains'] ?? [];
                foreach ($addonDomains as $ad) {
                    if (is_string($ad) && !empty($ad)) {
                        $vhosts[] = [
                            'vhost'       => $ad,
                            'version'     => '',
                            'php_admin'   => false,
                            'documentroot'=> '',
                        ];
                    }
                }
            }
        }

        // Get system default version
        $urlDefault = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=LangPHP"
             . "&cpanel_jsonapi_func=php_get_system_default_version";

        $rDefault = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlDefault);
        $defaultVersion = '';
        if ($rDefault['code'] === 200 && $rDefault['body']) {
            $json = json_decode($rDefault['body'], true);
            $defaultVersion = $json['result']['data'] ?? '';
            if (is_array($defaultVersion)) $defaultVersion = $defaultVersion['version'] ?? '';
        }

        // If no installed versions found but we have vhosts, extract versions from vhosts
        if (empty($installed) && !empty($vhosts)) {
            $fromVhosts = [];
            foreach ($vhosts as $vh) {
                if (!empty($vh['version'])) $fromVhosts[$vh['version']] = true;
            }
            if (!empty($defaultVersion)) $fromVhosts[$defaultVersion] = true;
            $installed = array_keys($fromVhosts);
            sort($installed);
        }

        // Last resort: try to get PHP version from phpinfo or shell
        if (empty($installed) && empty($vhosts)) {
            // Try to get at least the current PHP version via a simple exec
            $urlExec = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3"
                 . "&cpanel_jsonapi_module=Mime"
                 . "&cpanel_jsonapi_func=list_mime";

            // This is just a connectivity test — if it works, the server is reachable
            $rTest = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlExec);
            if ($rTest['code'] !== 200) {
                $debugInfo .= '. Server connectivity issue (HTTP ' . $rTest['code'] . ')';
            }
        }

        $result = [
            'success'   => true,
            'installed' => $installed,
            'vhosts'    => $vhosts,
            'default'   => $defaultVersion,
        ];
        if (empty($installed) && empty($vhosts)) {
            $result['success'] = false;
            $result['message'] = 'PHP version management is not available on this server' . ($debugInfo ? ' (' . $debugInfo . ')' : '');
        }
        echo json_encode($result);
        break;

    case 'php_set_version':
        $vhost   = isset($_POST['vhost']) ? trim($_POST['vhost']) : '';
        $version = isset($_POST['version']) ? trim($_POST['version']) : '';

        if (empty($vhost) || empty($version)) {
            echo json_encode(['success' => false, 'message' => 'Missing parameters']);
            exit;
        }

        $url = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=LangPHP"
             . "&cpanel_jsonapi_func=php_set_vhost_versions"
             . "&vhost=" . urlencode($vhost)
             . "&version=" . urlencode($version);

        $p = broodle_ajax_parse_result(broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $url));
        echo json_encode(['success' => $p['ok'], 'message' => $p['ok'] ? 'PHP version updated to ' . $version : $p['error']]);
        break;

    // ── Debug API Test ──
    case 'debug_api_test':
        $testModule = isset($_POST['module']) ? trim($_POST['module']) : '';
        $testFunc = isset($_POST['func']) ? trim($_POST['func']) : '';
        $testApiVer = isset($_POST['apiver']) ? trim($_POST['apiver']) : '3';
        $extraParams = isset($_POST['params']) ? trim($_POST['params']) : '';

        if (empty($testModule) || empty($testFunc)) {
            echo json_encode(['success' => false, 'message' => 'Missing module or func']);
            exit;
        }

        $testUrl = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=" . urlencode($testApiVer)
             . "&cpanel_jsonapi_module=" . urlencode($testModule)
             . "&cpanel_jsonapi_func=" . urlencode($testFunc);
        if (!empty($extraParams)) $testUrl .= '&' . $extraParams;

        $rTest = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $testUrl, 30);
        $testJson = null;
        if ($rTest['body']) $testJson = json_decode($rTest['body'], true);

        echo json_encode([
            'success' => true,
            'http_code' => $rTest['code'],
            'url' => $testUrl,
            'response' => $testJson,
            'raw_length' => strlen($rTest['body'] ?? ''),
            'server' => $hostname . ':' . $port,
            'user' => $cpUsername,
        ]);
        break;

    // ── Error Logs Actions ──

    case 'error_log_read':
        $lines = isset($_POST['lines']) ? (int) $_POST['lines'] : 100;
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        if ($lines < 10) $lines = 10;
        if ($lines > 500) $lines = 500;

        // Get home directory
        $homedir = '/home/' . $cpUsername;
        $urlHomedir = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=Fileman"
             . "&cpanel_jsonapi_func=getdir";
        $rHome = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlHomedir);
        if ($rHome['code'] === 200 && $rHome['body']) {
            $json = json_decode($rHome['body'], true);
            $dirData = $json['cpanelresult']['data'][0] ?? [];
            $h = $dirData['homedir'] ?? ($dirData['dir'] ?? '');
            if (!empty($h)) $homedir = $h;
        }

        $logContent = '';
        $logFile = '';
        $logEntries = [];

        // Get the main domain
        $mainDomain = $domain;
        if (empty($mainDomain)) {
            $urlDomain = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3"
                 . "&cpanel_jsonapi_module=DomainInfo"
                 . "&cpanel_jsonapi_func=list_domains";
            $rDomain = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlDomain);
            if ($rDomain['code'] === 200 && $rDomain['body']) {
                $jsonD = json_decode($rDomain['body'], true);
                $mainDomain = $jsonD['result']['data']['main_domain'] ?? '';
            }
            if (empty($mainDomain) && !empty($service->domain)) {
                $mainDomain = $service->domain;
            }
        }

        // Strategy 1: UAPI Stats::get_site_errors (most reliable, works on tested servers)
        if (!empty($mainDomain)) {
            $urlErrors = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3"
                 . "&cpanel_jsonapi_module=Stats"
                 . "&cpanel_jsonapi_func=get_site_errors"
                 . "&domain=" . urlencode($mainDomain)
                 . "&log=error"
                 . "&maxlines=" . $lines;
            $rErrors = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlErrors, 30);
            if ($rErrors['code'] === 200 && $rErrors['body']) {
                $json = json_decode($rErrors['body'], true);
                $status = $json['result']['status'] ?? 0;
                if ($status == 1) {
                    $data = $json['result']['data'] ?? [];
                    if (is_array($data)) {
                        foreach ($data as $entry) {
                            if (is_array($entry) && isset($entry['entry'])) {
                                $logEntries[] = $entry['entry'];
                            } elseif (is_string($entry) && !empty($entry)) {
                                $logEntries[] = $entry;
                            }
                        }
                    }
                    if (!empty($logEntries)) {
                        $logContent = implode("\n", $logEntries);
                        $logFile = $mainDomain . ' Error Log';
                    }
                }
            }
        }

        // Strategy 2: Read PHP error log directly (logs/{domain_underscored}.php.error.log)
        if (empty($logContent) && !empty($mainDomain)) {
            $domainUnderscored = str_replace('.', '_', $mainDomain);
            $phpLogPaths = [
                $homedir . '/logs/' . $domainUnderscored . '.php.error.log',
                $homedir . '/logs/' . $mainDomain . '.error.log',
                $homedir . '/logs/' . $mainDomain . '-error.log',
                $homedir . '/logs/error.log',
                $homedir . '/public_html/error_log',
            ];
            foreach ($phpLogPaths as $path) {
                $urlRead = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                     . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                     . "&cpanel_jsonapi_apiversion=3"
                     . "&cpanel_jsonapi_module=Fileman"
                     . "&cpanel_jsonapi_func=get_file_content"
                     . "&dir=" . urlencode(dirname($path))
                     . "&file=" . urlencode(basename($path))
                     . "&from_charset=utf-8"
                     . "&to_charset=utf-8";
                $rRead = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlRead, 30);
                if ($rRead['code'] === 200 && $rRead['body']) {
                    $json = json_decode($rRead['body'], true);
                    $fStatus = $json['result']['status'] ?? 0;
                    if ($fStatus == 1) {
                        $content = $json['result']['data']['content'] ?? '';
                        if (!empty(trim($content))) {
                            $logContent = $content;
                            $logFile = basename($path);
                            break;
                        }
                    }
                }
            }
        }

        // Strategy 3: Try UAPI Logd::get_last_errors (newer cPanel only)
        if (empty($logContent) && !empty($mainDomain)) {
            $urlLogd = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3"
                 . "&cpanel_jsonapi_module=Logd"
                 . "&cpanel_jsonapi_func=get_last_errors"
                 . "&domain=" . urlencode($mainDomain)
                 . "&maxlines=" . $lines;
            $rLogd = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlLogd, 30);
            if ($rLogd['code'] === 200 && $rLogd['body']) {
                $json = json_decode($rLogd['body'], true);
                $status = $json['result']['status'] ?? 0;
                if ($status == 1) {
                    $data = $json['result']['data'] ?? [];
                    if (is_array($data)) {
                        foreach ($data as $entry) {
                            if (is_array($entry) && isset($entry['entry'])) {
                                $logEntries[] = $entry['entry'];
                            } elseif (is_string($entry) && !empty($entry)) {
                                $logEntries[] = $entry;
                            }
                        }
                    }
                    if (!empty($logEntries)) {
                        $logContent = implode("\n", $logEntries);
                        $logFile = $mainDomain . ' Error Log';
                    }
                }
            }
        }

        if (empty($logContent)) {
            echo json_encode(['success' => true, 'lines' => [], 'file' => '', 'total' => 0, 'showing' => 0, 'message' => 'No error logs found']);
            exit;
        }

        $allLines = explode("\n", $logContent);
        $allLines = array_filter($allLines, function($l) { return trim($l) !== ''; });
        $allLines = array_values($allLines);
        $totalLines = count($allLines);
        $returnLines = array_slice($allLines, max(0, $totalLines - $lines));

        echo json_encode([
            'success'    => true,
            'lines'      => $returnLines,
            'file'       => $logFile,
            'total'      => $totalLines,
            'showing'    => count($returnLines),
        ]);
        break;

    case 'error_log_clear':
        /* Clear error logs by truncating known log files via POST */
        $homedir = '/home/' . $cpUsername;
        $urlHomedir = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=Fileman&cpanel_jsonapi_func=getdir";
        $rHome = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlHomedir);
        if ($rHome['code'] === 200 && $rHome['body']) {
            $json = json_decode($rHome['body'], true);
            $h = $json['cpanelresult']['data'][0]['homedir'] ?? ($json['cpanelresult']['data'][0]['dir'] ?? '');
            if (!empty($h)) $homedir = $h;
        }
        $cleared = false;
        /* Get main domain for domain-specific logs */
        $mainDomain = '';
        $urlDomain = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3&cpanel_jsonapi_module=DomainInfo&cpanel_jsonapi_func=list_domains";
        $rDomain = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlDomain);
        if ($rDomain['code'] === 200 && $rDomain['body']) {
            $jsonD = json_decode($rDomain['body'], true);
            $mainDomain = $jsonD['result']['data']['main_domain'] ?? '';
        }
        /* Build list of log paths to clear */
        $logPaths = [$homedir . '/public_html/error_log'];
        if (!empty($mainDomain)) {
            $domainUnderscored = str_replace('.', '_', $mainDomain);
            array_unshift($logPaths, $homedir . '/logs/' . $domainUnderscored . '.php.error.log');
            array_unshift($logPaths, $homedir . '/logs/' . $mainDomain . '.error.log');
            array_unshift($logPaths, $homedir . '/logs/' . $mainDomain . '-error.log');
        }
        $logPaths[] = $homedir . '/logs/error.log';
        /* Auth headers for direct curl calls */
        $clearHeaders = [];
        if (!empty($accessHash)) $clearHeaders[] = "Authorization: whm {$serverUser}:{$accessHash}";
        foreach ($logPaths as $path) {
            /* First check if file exists by trying to read it */
            $urlCheck = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3&cpanel_jsonapi_module=Fileman&cpanel_jsonapi_func=get_file_content"
                 . "&dir=" . urlencode(dirname($path)) . "&file=" . urlencode(basename($path))
                 . "&from_charset=utf-8&to_charset=utf-8";
            $rCheck = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlCheck);
            if ($rCheck['code'] === 200 && $rCheck['body']) {
                $jCheck = json_decode($rCheck['body'], true);
                if (($jCheck['result']['status'] ?? 0) != 1) continue; // File doesn't exist
                $content = $jCheck['result']['data']['content'] ?? '';
                if (empty(trim($content))) continue; // Already empty
            } else {
                continue;
            }
            /* Truncate the file via POST — GET with empty &content= drops the parameter */
            $urlSave = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
                 . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
                 . "&cpanel_jsonapi_apiversion=3&cpanel_jsonapi_module=Fileman&cpanel_jsonapi_func=save_file_content";
            $postData = http_build_query([
                'dir' => dirname($path),
                'file' => basename($path),
                'from_charset' => 'utf-8',
                'to_charset' => 'utf-8',
                'content' => '',
            ]);
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $urlSave,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $postData,
            ]);
            if (!empty($clearHeaders)) curl_setopt($ch, CURLOPT_HTTPHEADER, $clearHeaders);
            elseif (!empty($password)) curl_setopt($ch, CURLOPT_USERPWD, "{$serverUser}:{$password}");
            $rSave = curl_exec($ch);
            curl_close($ch);
            if ($rSave) {
                $json = json_decode($rSave, true);
                if (($json['result']['status'] ?? 0) == 1) $cleared = true;
            }
        }
        echo json_encode(['success' => $cleared, 'message' => $cleared ? 'Error log cleared' : 'No error logs found to clear']);
        break;

    /* ═══ ANALYTICS ═══ */
    case 'analytics_bandwidth':
        /* Get bandwidth data via UAPI Stats::get_bandwidth */
        $urlBw = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Stats"
             . "&cpanel_jsonapi_func=get_bandwidth";
        $rBw = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlBw, 30);
        if ($rBw['code'] === 200 && $rBw['body']) {
            $json = json_decode($rBw['body'], true);
            $status = $json['result']['status'] ?? 0;
            if ($status == 1) {
                echo json_encode(['success' => true, 'data' => $json['result']['data'] ?? []]);
            } else {
                echo json_encode(['success' => false, 'message' => $json['result']['errors'][0] ?? 'Failed to get bandwidth']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    case 'analytics_visitors':
        /* Get visitor stats links via API2 Stats::listwebalizer + Stats::listanalog */
        $domain = isset($_POST['domain']) ? trim($_POST['domain']) : '';
        $visitors = ['webalizer' => [], 'analog' => []];
        /* Webalizer */
        $urlW = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=Stats"
             . "&cpanel_jsonapi_func=listwebalizer";
        $rW = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlW, 20);
        if ($rW['code'] === 200 && $rW['body']) {
            $json = json_decode($rW['body'], true);
            $data = $json['cpanelresult']['data'] ?? [];
            if (is_array($data)) {
                foreach ($data as $d) {
                    if (isset($d['domain'])) {
                        $visitors['webalizer'][] = ['domain' => $d['domain'], 'link' => $d['link'] ?? ''];
                    }
                }
            }
        }
        /* Analog */
        $urlA = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=2"
             . "&cpanel_jsonapi_module=Stats"
             . "&cpanel_jsonapi_func=listanalog";
        $rA = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlA, 20);
        if ($rA['code'] === 200 && $rA['body']) {
            $json = json_decode($rA['body'], true);
            $data = $json['cpanelresult']['data'] ?? [];
            if (is_array($data)) {
                foreach ($data as $d) {
                    if (isset($d['domain'])) {
                        $visitors['analog'][] = ['domain' => $d['domain'], 'link' => $d['link'] ?? ''];
                    }
                }
            }
        }
        echo json_encode(['success' => true, 'visitors' => $visitors]);
        break;

    case 'analytics_log_archives':
        /* Get archived log files via UAPI LogManager::list_archives */
        $urlLogs = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=LogManager"
             . "&cpanel_jsonapi_func=list_archives";
        $rLogs = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlLogs, 20);
        if ($rLogs['code'] === 200 && $rLogs['body']) {
            $json = json_decode($rLogs['body'], true);
            $status = $json['result']['status'] ?? 0;
            if ($status == 1) {
                echo json_encode(['success' => true, 'archives' => $json['result']['data'] ?? []]);
            } else {
                echo json_encode(['success' => false, 'message' => $json['result']['errors'][0] ?? 'Failed to list archives']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    case 'analytics_bandwidth_detailed':
        /* Get monthly bandwidth per domain via UAPI Bandwidth::query */
        $grouping = isset($_POST['grouping']) ? trim($_POST['grouping']) : 'domain|protocol|year_month';
        // Sanitize grouping — only allow known values
        $allowedGroupings = ['domain', 'protocol', 'year_month', 'year_month_day', 'year'];
        $parts = explode('|', $grouping);
        $parts = array_filter($parts, function ($p) use ($allowedGroupings) { return in_array(trim($p), $allowedGroupings); });
        if (empty($parts)) $parts = ['domain', 'protocol', 'year_month'];
        $grouping = implode('|', $parts);

        // Default: last 6 months
        $end = time();
        $start = isset($_POST['start']) ? (int) $_POST['start'] : ($end - 180 * 86400);

        $urlBwD = "{$protocol}://{$hostname}:{$port}/json-api/cpanel"
             . "?cpanel_jsonapi_user=" . urlencode($cpUsername)
             . "&cpanel_jsonapi_apiversion=3"
             . "&cpanel_jsonapi_module=Bandwidth"
             . "&cpanel_jsonapi_func=query"
             . "&grouping=" . urlencode($grouping)
             . "&start=" . $start
             . "&end=" . $end
             . "&interval=daily"
             . "&protocols=" . urlencode('http|imap|smtp|pop3|ftp');
        $rBwD = broodle_ajax_whm_call($protocol, $hostname, $port, $serverUser, $accessHash, $password, $urlBwD, 30);
        if ($rBwD['code'] === 200 && $rBwD['body']) {
            $json = json_decode($rBwD['body'], true);
            $status = $json['result']['status'] ?? 0;
            if ($status == 1) {
                echo json_encode(['success' => true, 'data' => $json['result']['data'] ?? []]);
            } else {
                echo json_encode(['success' => false, 'message' => $json['result']['errors'][0] ?? 'Failed to get bandwidth details']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to connect to server']);
        }
        break;

    /* ═══ FILE MANAGER ═══ */
    case 'fm_list':
    case 'fm_read':
    case 'fm_save':
    case 'fm_create_file':
    case 'fm_create_folder':
    case 'fm_delete':
    case 'fm_rename':
    case 'fm_copy':
    case 'fm_move':
    case 'fm_upload':
    case 'fm_permissions':
    case 'fm_compress':
    case 'fm_extract':
    case 'fm_search':
    case 'fm_download_url':
        require_once __DIR__ . '/ajax_filemanager.php';
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action']);
}

